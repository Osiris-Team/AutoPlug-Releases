#!/bin/bash
java -jar AutoPlug-Client.jar
