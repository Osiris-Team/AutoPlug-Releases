#!/bin/bash
java -jar AutoPlug.jar
